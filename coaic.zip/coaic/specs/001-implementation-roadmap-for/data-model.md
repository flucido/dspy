# Data Model

## Config.yaml

Fields: model alias (string), API key (string)

Relationships: Used by LiteLLM Proxy

## LiteLLM Proxy

Fields: endpoint (string), container (string)

Relationships: Routes to Gemini API