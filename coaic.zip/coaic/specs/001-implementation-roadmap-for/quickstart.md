# Quickstart

1. Install Docker

2. Create config.yaml with model alias and API key

3. Run docker run -p 4000:4000 -v $(pwd)/config.yaml:/app/config.yaml -e GOOGLE_API_KEY=$GOOGLE_API_KEY ghcr.io/berriai/litellm:main-latest --config /app/config.yaml

4. Test curl http://localhost:4000/chat -d '{"model": "gemini-free", "messages": [{"role": "user", "content": "Hello"}]}'