import pytest
from unittest.mock import patch, MagicMock
from src.models.config import Config
from src.services.proxy import Proxy

@pytest.fixture
def config():
    return Config(model_alias="gemini-free", api_key="test-key")

def test_proxy_init(config):
    proxy = Proxy(config)
    assert proxy.config == config
    assert proxy.endpoint == "http://localhost:4000"
    assert proxy.container_name == "litellm-proxy"

@patch('src.services.proxy.subprocess.run')
def test_proxy_start(mock_run, config):
    proxy = Proxy(config)
    with patch.object(proxy, 'is_running', return_value=False):
        proxy.start()
        assert mock_run.call_count == 1  # only the docker run

@patch('src.services.proxy.subprocess.run')
def test_proxy_stop(mock_run, config):
    proxy = Proxy(config)
    with patch.object(proxy, 'is_running', return_value=True):
        proxy.stop()
        assert mock_run.call_count == 2  # stop and rm

@patch('src.services.proxy.subprocess.run')
def test_proxy_is_running(mock_run, config):
    mock_run.return_value.stdout = "litellm-proxy"
    proxy = Proxy(config)
    assert proxy.is_running() == True