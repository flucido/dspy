import pytest
from src.models.config import Config

def test_config_creation():
    config = Config(model_alias="gemini-free", api_key="test-key")
    assert config.model_alias == "gemini-free"
    assert config.api_key == "test-key"

def test_config_equality():
    config1 = Config(model_alias="gemini-free", api_key="test-key")
    config2 = Config(model_alias="gemini-free", api_key="test-key")
    assert config1 == config2