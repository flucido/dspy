import pytest
from jsonschema import validate, ValidationError

def test_chat_request_schema():
    request_schema = {
        "type": "object",
        "properties": {
            "model": {"type": "string"},
            "messages": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "role": {"type": "string"},
                        "content": {"type": "string"}
                    },
                    "required": ["role", "content"]
                }
            }
        },
        "required": ["model", "messages"]
    }
    
    valid_request = {
        "model": "gemini-free",
        "messages": [{"role": "user", "content": "Hello"}]
    }
    
    validate(instance=valid_request, schema=request_schema)
    
    # Test invalid request
    with pytest.raises(ValidationError):
        invalid_request = {"model": "gemini-free"}  # missing messages
        validate(instance=invalid_request, schema=request_schema)

def test_chat_response_schema():
    response_schema = {
        "type": "object",
        "properties": {
            "response": {"type": "string"}
        },
        "required": ["response"]
    }
    
    valid_response = {"response": "Hello, how can I help?"}
    
    validate(instance=valid_response, schema=response_schema)
    
    # Test invalid response
    with pytest.raises(ValidationError):
        invalid_response = {}  # missing response
        validate(instance=invalid_response, schema=response_schema)