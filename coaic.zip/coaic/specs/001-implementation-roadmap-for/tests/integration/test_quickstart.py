import subprocess
import time
import requests
import pytest
import os

def test_quickstart_scenario():
    # Assume GOOGLE_API_KEY is set
    api_key = os.getenv('GOOGLE_API_KEY')
    if not api_key:
        pytest.skip("GOOGLE_API_KEY not set")
    
    # Start LiteLLM proxy in background
    cmd = [
        'docker', 'run', '-d', '--name', 'litellm-proxy', '-p', '4000:4000',
        '-v', f'{os.getcwd()}/config.yaml:/app/config.yaml',
        '-e', f'GOOGLE_API_KEY={api_key}',
        'ghcr.io/berriai/litellm:main-latest', '--config', '/app/config.yaml'
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    try:
        time.sleep(5)  # Wait for proxy to start
        
        # Send chat request
        payload = {
            "model": "gemini-free",
            "messages": [{"role": "user", "content": "Hello"}]
        }
        response = requests.post('http://localhost:4000/chat', json=payload)
        
        assert response.status_code == 200
        assert 'response' in response.json()
        
    finally:
        # Stop the container
        subprocess.run(['docker', 'stop', 'litellm-proxy'], check=True)
        subprocess.run(['docker', 'rm', 'litellm-proxy'], check=True)