from dataclasses import dataclass

@dataclass
class Config:
    model_alias: str
    api_key: str