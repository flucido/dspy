import argparse
import requests
from src.models.config import Config
from src.services.proxy import Proxy

def main():
    parser = argparse.ArgumentParser(description="Chat with the agent")
    parser.add_argument('message', type=str, help='Message to send')
    args = parser.parse_args()
    
    # Load config (assume config.yaml exists)
    config = Config(model_alias="gemini-free", api_key="")  # API key from env
    proxy = Proxy(config)
    proxy.start()
    
    try:
        payload = {
            "model": config.model_alias,
            "messages": [{"role": "user", "content": args.message}]
        }
        response = requests.post(f"{proxy.endpoint}/chat", json=payload)
        print(response.json().get('response', 'No response'))
    finally:
        proxy.stop()

if __name__ == "__main__":
    main()