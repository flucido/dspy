import subprocess
import time
import os
import logging
from src.models.config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RateLimiter:
    def __init__(self, calls_per_minute=60):
        self.calls_per_minute = calls_per_minute
        self.call_times = []
    
    def can_make_call(self):
        now = time.time()
        self.call_times = [t for t in self.call_times if now - t < 60]
        if len(self.call_times) < self.calls_per_minute:
            self.call_times.append(now)
            return True
        return False

class Proxy:
    def __init__(self, config: Config):
        self.config = config
        self.endpoint = "http://localhost:4000"
        self.container_name = "litellm-proxy"
        self.rate_limiter = RateLimiter(calls_per_minute=60)  # Free tier limit
    
    def start(self):
        if self.is_running():
            logger.info("Proxy already running")
            return
        logger.info("Starting LiteLLM proxy container")
        cmd = [
            'docker', 'run', '-d', '--name', self.container_name, '-p', '4000:4000',
            '-v', f'{os.getcwd()}/config.yaml:/app/config.yaml',
            '-e', f'GOOGLE_API_KEY={self.config.api_key}',
            'ghcr.io/berriai/litellm:main-latest', '--config', '/app/config.yaml'
        ]
        subprocess.run(cmd, check=True)
        time.sleep(5)  # Wait for startup
        logger.info("Proxy started successfully")
    
    def stop(self):
        if self.is_running():
            logger.info("Stopping proxy container")
            subprocess.run(['docker', 'stop', self.container_name], check=True)
            subprocess.run(['docker', 'rm', self.container_name], check=True)
            logger.info("Proxy stopped")
    
    def is_running(self):
        result = subprocess.run(['docker', 'ps', '--filter', f'name={self.container_name}', '--format', '{{.Names}}'], capture_output=True, text=True)
        running = self.container_name in result.stdout
        logger.debug(f"Proxy running: {running}")
        return running
    
    def make_request(self, payload):
        if not self.rate_limiter.can_make_call():
            logger.warning("Rate limit exceeded, waiting...")
            time.sleep(60)
            if not self.rate_limiter.can_make_call():
                raise Exception("Rate limit exceeded")
        # Here, the request would be made, but since proxy is external, just log
        logger.info("Making request to proxy")