import requests
from src.models.config import Config

class APIClient:
    def __init__(self, config: Config):
        self.config = config
        self.base_url = "http://localhost:4000"
    
    def chat(self, messages):
        payload = {
            "model": self.config.model_alias,
            "messages": messages
        }
        response = requests.post(f"{self.base_url}/chat", json=payload)
        response.raise_for_status()
        return response.json().get('response')