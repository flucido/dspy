# LiteLLM Proxy with Google Gemini Free Tier

This project implements a cost-optimized personal coding agent using LiteLLM proxy with Google Gemini free tier.

## Setup

1. Install Docker and Python 3.11.

2. Set your Google API key as environment variable: `export GOOGLE_API_KEY=your_key`

3. Create `config.yaml` with:
   ```yaml
   model:
     - model_name: gemini-free
       litellm_params:
         model: gemini-1.5-flash
         api_key: os.environ.get("GOOGLE_API_KEY")
   ```

4. Run the proxy:
   ```bash
   docker run -p 4000:4000 -v $(pwd)/config.yaml:/app/config.yaml -e GOOGLE_API_KEY=$GOOGLE_API_KEY ghcr.io/berriai/litellm:main-latest --config /app/config.yaml
   ```

## Usage

Use the CLI:
```bash
python -m src.cli.chat "Hello, how can I help?"
```

Or use the API client:
```python
from src.models.config import Config
from src.lib.client import APIClient

config = Config(model_alias="gemini-free", api_key="your_key")
client = APIClient(config)
response = client.chat([{"role": "user", "content": "Hello"}])
print(response)
```

## Testing

Run tests with:
```bash
source venv/bin/activate
pytest
```