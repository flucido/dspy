# AGENTS.md

## Build/Lint/Test Commands
- No standard build commands; use bash scripts in .specify/scripts/bash/ for setup and validation.
- Run prerequisites check: `./.specify/scripts/bash/check-prerequisites.sh` (supports --json, --require-tasks, etc.)
- No lint commands; ensure bash scripts follow best practices.
- No test commands; no test files present. For single test, none available.

## Code Style Guidelines
- **Language**: Bash scripts.
- **Shebang**: Use `#!/usr/bin/env bash` at top.
- **Indentation**: 4 spaces (no tabs).
- **Functions**: Define with `function_name() { ... }`, use camelCase.
- **Variables**: UPPER_CASE, e.g., `REPO_ROOT`.
- **Imports**: Source scripts with `source "$SCRIPT_DIR/common.sh"`.
- **Error Handling**: Use `set -e`, echo errors to stderr (`>&2`), exit with non-zero code on failure.
- **Formatting**: Consistent spacing, no trailing whitespace, heredoc for multi-line strings.
- **Naming Conventions**: Functions camelCase, variables UPPER_CASE, branch names like 001-feature-name.
- **Comments**: Use `#` for comments, explain complex logic and usage.
- No Cursor rules (no .cursor/ directory) or Copilot instructions (no .github/copilot-instructions.md) present.
